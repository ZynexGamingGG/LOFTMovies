import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN   = os.getenv("BOT_TOKEN", "8008714660:AAHUSyPesuhYgoORm8T4TZh8RMQqHXctmN8")
ADMIN_IDS   = list(map(int, os.getenv("ADMIN_IDS", "123456789").split(",")))
DB_PATH     = "kinobot.db"
CHANNEL_URL = os.getenv("CHANNEL_URL", "https://instagram.com/sizning_sahifa")
